#include "tables.h"

//void push_to_label_table(LabelTable **label_table, int *label_index, ) ;
//
//}
