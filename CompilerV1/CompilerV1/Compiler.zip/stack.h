#ifndef _STACK_H
#define _STACK_H

void push(int *stack, int *top, int data);
int pop(int *stack, int *top);

#endif