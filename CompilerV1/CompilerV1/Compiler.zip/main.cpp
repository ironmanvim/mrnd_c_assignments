#include <stdio.h>
#include "Compiler.h"

int main() {
	process_opcode_of_file("program.txt", "resultopcode.txt");
}
